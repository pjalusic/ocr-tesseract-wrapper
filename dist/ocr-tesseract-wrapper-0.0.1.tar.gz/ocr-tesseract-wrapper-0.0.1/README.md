# ocr-tesseract-wrapper
Tiny wrapper around pytesseract with image preprocessing and OCR configurations

## Requirements
- tesseract installed (https://github.com/tesseract-ocr/tesseract/wiki#installation)
- python packages:
  - opencv-python
  - tesseract